<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="10"/>
        <source>Logowanie</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
